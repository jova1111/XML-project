/**
 * 
 * HTTP cloud function provides greeting feature. Responds to any HTTP request
 * that can provide "name" field in HTTP body or as a request parameter.
 *
 * @param {!Object} req Cloud Function request context.
 * @param {!Object} res Cloud Function response context.
 */
 
require('@google/cloud-debug');
exports.addRating = function addRating(req, res) {
  
  let idLodging = req.query.id || req.body.lodgingId;
  let comment = req.query.comment || req.body.content;
  let rating = req.query.rating || req.body.rating;
  let userEmail = req.query.userEmail || req.body.publisherEmail

  var mysql = require('mysql');

  var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'booking'
  });

  con.connect(function(err) {
    if (err) throw err;
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    let query = 'INSERT INTO comment (content, lodging_id, approved, rating, publisher_email) VALUES ?';
    values = [[ comment, idLodging, false, rating, userEmail ]];
    con.query(query, [values], function (err, result, fields) {
        if(err) {
          res.status(500).send(err)
        }
        res.status(200).send(result);
    });
  }); 

    

};


exports.searchRating = function searchRating(req, res) {
  
let rating = req.query.rating || req.body.rating;

var mysql = require('mysql');

var con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'booking'
});

con.connect(function(err) {
  if (err) throw err;
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  let sql = 'SELECT * FROM lodging INNER JOIN comment ON lodging.id = comment.lodging_id WHERE comment.rating >= ?';
  con.query(sql, [ rating ] , function (err, result, fields) {
    if(err) {
      res.status(500).send(err)
    }
    res.status(200).send(result);
  });
}); 

  

};